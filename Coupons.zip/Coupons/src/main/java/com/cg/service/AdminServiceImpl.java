package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Coupon;
import com.cg.repo.CouponRepo;

@Service(value="adminServices")
public class AdminServiceImpl implements AdminServices {
	@Autowired
	private CouponRepo couponRepo;
    
	
	
	
	public Coupon addCoupon(Coupon coupon) {
		// TODO Auto-generated method stub
		return couponRepo.save(coupon);
	}

	public void removeCoupon(int couponId) {
		// TODO Auto-generated method stub
		couponRepo.deleteById(couponId);
	}

	public double applyCoupon(int cartId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
