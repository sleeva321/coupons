package com.cg.service;

import com.cg.beans.Coupon;

public interface AdminServices {
public Coupon addCoupon(Coupon coupon);
	
	public void removeCoupon(int couponId);

	public double applyCoupon(int cartId);

}
