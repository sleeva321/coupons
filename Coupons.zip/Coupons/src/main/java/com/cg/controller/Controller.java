package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Coupon;
import com.cg.service.AdminServices;

@RestController
public class Controller {
	@Autowired
	private AdminServices adminService;
	@RequestMapping(value = "/addCoupon", method = RequestMethod.POST)
	public void addCoupon(@RequestBody Coupon coupon) {

		adminService.addCoupon(coupon);
	}

	@RequestMapping(value = "/removeCoupon")
	public void removeCoupon(int couponId) {
		adminService.removeCoupon(couponId);
	}
	 
	@RequestMapping(value = "/getCoupon")
	public double getCouponDetails(int cartId)
	{
		double price =  adminService.applyCoupon(cartId);
		return  price;
	}


}
