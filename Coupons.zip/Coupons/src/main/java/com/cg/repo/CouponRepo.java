package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Coupon;

public interface CouponRepo extends JpaRepository<Coupon, Integer> {

	void deleteById(int couponId);

	Coupon save(Coupon coupon);

	

}
